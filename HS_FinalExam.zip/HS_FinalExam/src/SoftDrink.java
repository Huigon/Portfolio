/**
 * Program Name:	SoftDrink.java
 * Purpose:			To create an object class for SoftDrink
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Apr 23, 2021
 */

public class SoftDrink 
{
	//Declare private fields
	private String name;
	private double price;
	private int quantity;
	
	/**
	 * Constructs a new SoftDrink object
	 * @param name
	 * @param price
	 * @param quantity
	 */
	public SoftDrink(String name, double price, int quantity)
	{
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}//End of constructor

	/**
	 * Gets the name of this object  
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}//End of getName()

	/**
	 * Gets the price of this object  
	 * @return the price
	 */
	public double getPrice()
	{
		return price;
	}//End of getPrice()

	/**
	 * Gets the quantity of this object  
	 * @return the quantity
	 */
	public int getQuantity()
	{
		return quantity;
	}//End of getQuantity()

	/**
	 * Sets the name of this object
	 * @param name - the value to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}//End of setName()

	/**
	 * Sets the price of this object
	 * @param price - the value to set
	 */
	public void setPrice(double price)
	{
		this.price = price;
	}//End of setPrice()

	/**
	 * Sets the quantity of this object
	 * @param quantity - the value to set
	 */
	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}//End of setQuantity()
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		return String.format("Payment for %s is $%.2f. Enter coins($1 or $2).", this.getName(), this.getPrice());
	}//End of toString()
}//End of class