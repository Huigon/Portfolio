window.onload = function() {

    //Create Device class
    class Device
    {
        //Declare private properties
        #status = 0;
        #replacementCost = 0;
        #supplierName = '';
        #serialNumber = '';

        //Set constructor
        constructor(status, replacementCost, supplierName, serialNumber) {        
            parseInt(status) === 1 ? this.enable() : this.disable();
            this.setReplacementCost(replacementCost);
            this.setSupplierName(supplierName);
            this.setSerialNumber(serialNumber);
        }

        //Create methods including getters and setters
        enable() {
            this.#status = 1;
        }

        disable() {
            this.#status = 0;
        }

        getStatus() {
            return this.#status;
        }

        setReplacementCost(replacementCost) {
            this.#replacementCost = replacementCost;
        }

        getReplacementCost() {
            return this.#replacementCost;
        }

        setSupplierName(supplierName) {
            this.#supplierName = supplierName;
        }

        getSupplierName() {
            return this.#supplierName;
        }

        setSerialNumber(serialNumber) {
            this.#serialNumber = serialNumber;
        }

        getSerialNumber() {
            return this.#serialNumber;
        }
    }

    //Create VideoDevice class inherited from Device class
    class VideoDevice extends Device
    {
        //Declare private properties
        #resolution = '';
        #type = '';

        //Set constructor
        constructor(status, replacementCost, supplierName, serialNumber, resolution, type) {
            super(status, replacementCost, supplierName, serialNumber);
            this.setResolution(resolution);
            this.setType(type);
        }

        //Create methods including getters and setters
        setResolution(resolution) {
            this.#resolution = resolution;
        }

        getResolution() {
            return this.#resolution;
        }
        
        setType(type) {
            this.#type = type;
        }

        getType() {
            return this.#type;
        }

        //Display current object
        output() {
            var deviceType = ['LCD', 'LED', 'Plasma'];

            if(this.getStatus() === 1) {
                document.getElementById("videoCheckbox").checked = true;
            } else {
                document.getElementById("videoCheckbox").checked = false;
            } 

            document.getElementById("videoReplacementCost").value = this.getReplacementCost();
            document.getElementById("videoSupplierName").value = this.getSupplierName();
            document.getElementById("videoSerialNumber").value = this.getSerialNumber();
            document.getElementById("videoResolution").value = this.getResolution();
            
            for(var i = 0; i < deviceType.length; i++) {

                if(this.getType() === deviceType[i]) {
                    document.getElementById(deviceType[i]).selected = true;
                } else {
                    document.getElementById(deviceType[i]).selected = false;
                }
            }
        }

        //Update object and display again
        update(newFields) {
            //update element fields
            newFields.getStatus() === 1 ? this.enable() : this.disable();
            this.setReplacementCost(newFields.getReplacementCost());
            this.setSupplierName(newFields.getSupplierName());
            this.setSerialNumber(newFields.getSerialNumber());
            this.setResolution(newFields.getResolution());
            this.setType(newFields.getType());

            //re-output element
            this.output();
        }
    }

    //Create DiskDevice class inherited from Device class
    class DiskDevice extends Device
    {
        //Declare private properties
        #size = '';
        #transferRate = '';

        //Set constructor
        constructor(status, replacementCost, supplierName, serialNumber, size, transferRate) {
            super(status, replacementCost, supplierName, serialNumber);
            this.setSize(size);
            this.setTransferRate(transferRate);
        }

        //Create methods including getters and setters
        setSize(size) {
            this.#size = size;
        }

        getSize() {
            return this.#size;
        }
        
        setTransferRate(transferRate) {
            this.#transferRate = transferRate;
        }

        getTransferRate() {
            return this.#transferRate;
        }
    }

    //Create HardDiskDevice class inherited from DiskDevice class
    class HardDiskDevice extends DiskDevice
    {
        //Declare private properties
        #platterSize = '';
        #plattersNumber = 0;

        //Set constructor
        constructor(status, replacementCost, supplierName, serialNumber, size, transferRate, plattersNumber, platterSize) {
            super(status, replacementCost, supplierName, serialNumber, size, transferRate);
            this.setPlatterSize(platterSize);
            this.setPlattersNumber(plattersNumber);
        }

        //Create methods including getters and setters
        setPlatterSize(platterSize) {
            this.#platterSize = platterSize;
        }
        
        getPlatterSize() {
            return this.#platterSize;
        }

        setPlattersNumber(plattersNumber) {
            this.#plattersNumber = plattersNumber;
        }

        getPlattersNumber() {
            return this.#plattersNumber;
        }

        //Display current object
        output() {
            if(this.getStatus() === 1) {
                document.getElementById("hddCheckbox").checked = true;
            } else {
                document.getElementById("hddCheckbox").checked = false;
            } 

            document.getElementById("hddReplacementCost").value = this.getReplacementCost();
            document.getElementById("hddSupplierName").value = this.getSupplierName();
            document.getElementById("hddSerialNumber").value = this.getSerialNumber();
            document.getElementById("hddSize").value = this.getSize();
            document.getElementById("hddTransferRate").value = this.getTransferRate();
            document.getElementById("hddPlattersNumber").value = this.getPlattersNumber();
            document.getElementById("hddPlatterSize").value = this.getPlatterSize();
        }

        //Update object and display again
        update(newFields) {
            //update element fields
            newFields.getStatus() === 1 ? this.enable() : this.disable();
            this.setReplacementCost(newFields.getReplacementCost());
            this.setSupplierName(newFields.getSupplierName());
            this.setSerialNumber(newFields.getSerialNumber());
            this.setSize(newFields.getSize());
            this.setTransferRate(newFields.getTransferRate());
            this.setPlattersNumber(newFields.getPlattersNumber());
            this.setPlatterSize(newFields.getPlatterSize());

            //re-output element
            this.output();
        }
    }

    //Create SSDDevice class inherited from DiskDevice class
    class SSDDevice extends DiskDevice
    {
        //Declare private properties
        #type = '';
        #wearLeveling = false;
        
        //Set constructor
        constructor(status, replacementCost, supplierName, serialNumber, size, transferRate, type, wearLeveling) {
            super(status, replacementCost, supplierName, serialNumber, size, transferRate);
            this.setType(type);
            this.setWearLeveling(wearLeveling);
        }
        
        //Create methods including getters and setters
        setType(type) {
            this.#type = type;
        }

        getType() {
            return this.#type;
        }
        
        setWearLeveling(wearLeveling) {
            this.#wearLeveling = wearLeveling;
        }

        getWearLeveling() {
            return this.#wearLeveling;
        }

        //Display current object
        output() {
            var deviceType = ['Flash', 'DRAM'];

            if(this.getStatus() === 1) {
                document.getElementById("ssdCheckbox").checked = true;
            } else {
                document.getElementById("ssdCheckbox").checked = false;
            } 

            document.getElementById("ssdReplacementCost").value = this.getReplacementCost();
            document.getElementById("ssdSupplierName").value = this.getSupplierName();
            document.getElementById("ssdSerialNumber").value = this.getSerialNumber();
            document.getElementById("ssdSize").value = this.getSize();
            document.getElementById("ssdTransferRate").value = this.getTransferRate();

            for(var i = 0; i < deviceType.length; i++) {

                if(this.getType() === deviceType[i]) {
                    document.getElementById(deviceType[i]).selected = true;
                } else {
                    document.getElementById(deviceType[i]).selected = false;
                }
            }

            if(this.getWearLeveling() == true) {
                document.getElementById("ssdWearLeveling").checked = true;
            } else {
                document.getElementById("ssdWearLeveling").checked = false;
            } 
        }

        //Update object and display again
        update(newFields) {
            //update element fields
            newFields.getStatus() === 1 ? this.enable() : this.disable();
            this.setReplacementCost(newFields.getReplacementCost());
            this.setSupplierName(newFields.getSupplierName());
            this.setSerialNumber(newFields.getSerialNumber());
            this.setSize(newFields.getSize());
            this.setTransferRate(newFields.getTransferRate());
            this.setType(newFields.getType());

            if(newFields.getWearLeveling() == true) {
                this.setWearLeveling(true);
            }
            else {
                this.setWearLeveling(false);
            }

            //re-output element
            this.output();
        }
    }

    //Create a list for entire objects
    let devices = {
        'items': {
            'video': {
                'currentIndex': 0,
                'items': [],
            },
            'hdd': {
                'currentIndex': 0,
                'items': [],
            },
            'ssd': {
                'currentIndex': 0,
                'items': [],
            },
        },

        //Add current object according to device type
        addDevice(type, device) {
            if(!['video', 'hdd', 'ssd'].includes(type)) {
                throw new Error('Unknown device type! Have to be one of "video", "hdd" or "ssd".');
            }

            this.items[type].items.push(device);
            if(this.items[type].currentIndex === -1) {
                this.items[type].currentIndex = 0;
            }
        }
    };

    //Create and add devices
    devices.addDevice('video', new VideoDevice(
        1,
        400,
        'Samsung',
        '1224953148',
        '1920x1080',
        'LED'
    ));

    devices.addDevice('video', new VideoDevice(
        0,
        500,
        'Dell',
        '4597821489',
        '2560x1440',
        'LCD'
    ));

    devices.addDevice('video', new VideoDevice(
        1,
        550,
        'HP',
        '1033504840',
        '3840x2160',
        'Plasma'
    ));

    devices.addDevice('hdd', new HardDiskDevice(
        1,
        140,
        'Seagate',
        '47501499956',
        '4TB',
        '6GB / second',
        1,
        '3.2 inches'
    ));

    devices.addDevice('hdd', new HardDiskDevice(
        1,
        120,
        'Toshiba',
        '8810364219',
        '2TB',
        '5GB / second',
        2,
        '3.5 inches'
    ));

    devices.addDevice('hdd', new HardDiskDevice(
        0,
        100,
        'Western Digital',
        '5548031264',
        '1TB',
        '6GB / second',
        1,
        '2.5 inches'
    ));

    devices.addDevice('ssd', new SSDDevice(
        1,
        250,
        'Samsung',
        '1054567841',
        '1TB',
        '6GB / second',
        'DRAM',
        false
    ));

    devices.addDevice('ssd', new SSDDevice(
        1,
        200,
        'Crucial',
        '4124593033',
        '1TB',
        '5GB / second',
        'DRAM',
        false
    ));

    devices.addDevice('ssd', new SSDDevice(
        0,
        500,
        'Kingston',
        '7891571810',
        '240GB',
        '5GB / second',
        'Flash',
        true
    ));

    //Display the first objects of each device type
    devices.items['video'].items[0].output();
    devices.items['hdd'].items[0].output();
    devices.items['ssd'].items[0].output();

    //Function for previous button of video device
    const loadPreviousVideo = () => {
        --devices.items['video'].currentIndex;
        if(devices.items['video'].currentIndex === -1) {
            devices.items['video'].currentIndex = devices.items['video'].items.length - 1;
        }

        let currentElement = devices.items['video'].items[devices.items['video'].currentIndex];

        currentElement.output();    
    }

    //Function for previous button of hdd device
    const loadPreviousHdd = () => {
        --devices.items['hdd'].currentIndex;
        if(devices.items['hdd'].currentIndex === -1) {
            devices.items['hdd'].currentIndex = devices.items['hdd'].items.length - 1;
        }

        let currentElement = devices.items['hdd'].items[devices.items['hdd'].currentIndex];

        currentElement.output();    
    }

    //Function for previous button of ssd device
    const loadPreviousSsd = () => {
        --devices.items['ssd'].currentIndex;
        if(devices.items['ssd'].currentIndex === -1) {
            devices.items['ssd'].currentIndex = devices.items['ssd'].items.length - 1;
        }

        let currentElement = devices.items['ssd'].items[devices.items['ssd'].currentIndex];

        currentElement.output();    
    }

    //Function for next button of video device
    const loadNextVideo = () => {
        ++devices.items['video'].currentIndex;
        if(devices.items['video'].currentIndex === devices.items['video'].items.length) {
            devices.items['video'].currentIndex = 0;
        }

        let currentElement = devices.items['video'].items[devices.items['video'].currentIndex];

        currentElement.output();    
    }

    //Function for next button of hdd device
    const loadNextHdd = () => {
        ++devices.items['hdd'].currentIndex;
        if(devices.items['hdd'].currentIndex === devices.items['hdd'].items.length) {
            devices.items['hdd'].currentIndex = 0;
        }

        let currentElement = devices.items['hdd'].items[devices.items['hdd'].currentIndex];

        currentElement.output();    
    }

    //Function for next button of ssd device
    const loadNextSsd = () => {
        ++devices.items['ssd'].currentIndex;
        if(devices.items['ssd'].currentIndex === devices.items['ssd'].items.length) {
            devices.items['ssd'].currentIndex = 0;
        }

        let currentElement = devices.items['ssd'].items[devices.items['ssd'].currentIndex];

        currentElement.output();    
    }

    //Function for new button of video device
    const createNewVideo = () => {
        devices.items['video'].currentIndex = devices.items['video'].items.length - 1;
        let newItem = new VideoDevice(
            0,
            9999,
            'Supplier name here',
            '0000000000',
            '640x480',
            'LCD'
        );
        devices.addDevice('video', newItem);
        ++devices.items['video'].currentIndex;

        newItem.output();
    }

    //Function for new button of hdd device
    const createNewHdd = () => {
        devices.items['hdd'].currentIndex = devices.items['hdd'].items.length - 1;
        let newItem = new HardDiskDevice(
            0,
            9999,
            'Supplier name here',
            '0000000000',
            '512GB',
            '6GB / second',
            '1',
            '3.2 inches'
        );
        devices.addDevice('hdd', newItem);
        ++devices.items['hdd'].currentIndex;

        newItem.output();
    }

    //Function for new button of ssd device
    const createNewSsd = () => {
        devices.items['ssd'].currentIndex = devices.items['ssd'].items.length - 1;
        let newItem = new SSDDevice(
            0,
            9999,
            'Supplier name here',
            '0000000000',
            '512GB',
            '6GB / second',
            'Flash',
            false
        );
        devices.addDevice('ssd', newItem);
        ++devices.items['ssd'].currentIndex;

        newItem.output();
    }

    //Function for update button of video device
    const updateVideo = () => {
        let newItem = new VideoDevice();

        if(document.getElementById("videoCheckbox").checked == true) {
            newItem.enable();
        } else {
            newItem.disable();
        }

        newItem.setReplacementCost(document.getElementById("videoReplacementCost").value);
        newItem.setSupplierName(document.getElementById("videoSupplierName").value);
        newItem.setSerialNumber(document.getElementById("videoSerialNumber").value);
        newItem.setResolution(document.getElementById("videoResolution").value);
        newItem.setType(document.getElementById("videoType").value);

        devices.items['video'].items[devices.items['video'].currentIndex].update(newItem);
    }

    //Function for update button of hdd device
    const updateHdd = () => {
        let newItem = new HardDiskDevice();

        if(document.getElementById("hddCheckbox").checked == true) {
            newItem.enable();
        } else {
            newItem.disable();
        }

        newItem.setReplacementCost(document.getElementById("hddReplacementCost").value);
        newItem.setSupplierName(document.getElementById("hddSupplierName").value);
        newItem.setSerialNumber(document.getElementById("hddSerialNumber").value);
        newItem.setSize(document.getElementById("hddSize").value);
        newItem.setTransferRate(document.getElementById("hddTransferRate").value);
        newItem.setPlattersNumber(document.getElementById("hddPlattersNumber").value);
        newItem.setPlatterSize(document.getElementById("hddPlatterSize").value);

        devices.items['hdd'].items[devices.items['hdd'].currentIndex].update(newItem);
    }

    //Function for update button of ssd device
    const updateSsd = () => {
        let newItem = new SSDDevice();

        if(document.getElementById("ssdCheckbox").checked == true) {
            newItem.enable();
        } else {
            newItem.disable();
        }

        newItem.setReplacementCost(document.getElementById("ssdReplacementCost").value);
        newItem.setSupplierName(document.getElementById("ssdSupplierName").value);
        newItem.setSerialNumber(document.getElementById("ssdSerialNumber").value);
        newItem.setSize(document.getElementById("ssdSize").value);
        newItem.setTransferRate(document.getElementById("ssdTransferRate").value);
        newItem.setType(document.getElementById("ssdType").value);

        if(document.getElementById("ssdWearLeveling").checked == true) {
            newItem.setWearLeveling(true);
        } else {
            newItem.setWearLeveling(false);
        }
        
        devices.items['ssd'].items[devices.items['ssd'].currentIndex].update(newItem);
    }

    //Add EventListener for buttons
    document.getElementById('previousVideo').addEventListener("click", loadPreviousVideo);
    document.getElementById('previousHdd').addEventListener("click", loadPreviousHdd);
    document.getElementById('previousSsd').addEventListener("click", loadPreviousSsd);
    document.getElementById('nextVideo').addEventListener("click", loadNextVideo);
    document.getElementById('nextHdd').addEventListener("click", loadNextHdd);
    document.getElementById('nextSsd').addEventListener("click", loadNextSsd);
    document.getElementById('newVideo').addEventListener("click", createNewVideo);
    document.getElementById('newHdd').addEventListener("click", createNewHdd);
    document.getElementById('newSsd').addEventListener("click", createNewSsd);
    document.getElementById('updateVideo').addEventListener("click", updateVideo);
    document.getElementById('updateHdd').addEventListener("click", updateHdd);
    document.getElementById('updateSsd').addEventListener("click", updateSsd);
}