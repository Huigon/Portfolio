# What professor should know
- Valeria Carolina Chiari Santos did not attend Project 2.