/**
 * Program Name:	Customer.java
 * Purpose:			An abstract class to be extended by more specialized classes
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 16, 2021
 */

public abstract class Customer 
{
	//Declare instance field
	private String firstName;
	private String lastName;
	private String customerID;
	private String customerLevel;
	
	/**
	 * Constructs a new Customer object
	 * @param firstName - initializes firstName
	 * @param lastName - initializes lastName
	 * @param customerLevel - initializes customerLevel
	 */
	public Customer(String firstName, String lastName, String customerLevel)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.customerLevel = customerLevel;
		setCustomerID();
	}

	/**
	 * Gets the firstName of this object  
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}//End of getFirstName()

	/**
	 * Gets the lastName of this object  
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}//End of getLastName()

	/**
	 * Gets the customerID of this object  
	 * @return the customerID
	 */
	public String getCustomerID()
	{
		return customerID;
	}//End of getCustomerID()

	/**
	 * Gets the customerLevel of this object  
	 * @return the customerLevel
	 */
	public String getCustomerLevel()
	{
		return customerLevel;
	}//End of getCustomerLevel()

	/**
	 * Sets the firstName of this object
	 * @param firstName - the value to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}//End of setFirstName()

	/**
	 * Sets the lastName of this object
	 * @param lastName - the value to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}//End of setLastName()

	/**
	 * Sets the customerID of this object
	 * @param customerID - the value to set
	 */
	private void setCustomerID()
	{
		//Declare constants and variables to use
		final int MAXIMUM_NAME_LENGTH = 4;
		final int CUSTOMER_ID_NUMBER = 5;
		
		String cusLastName = "";
		String addCusLastName = "";
		
		//Check if there is a letter or not, and take only letters for last name
		for(int i = 0; i < lastName.length(); i++)
		{
			if(Character.isLetter(lastName.charAt(i)))
				cusLastName += Character.toUpperCase(lastName.charAt(i));
		}
		
		//take 4 characters from the last name, adding Xs if the length of last name is less than 4.
		if(cusLastName.length() < MAXIMUM_NAME_LENGTH)
		{			
			for(int i = 0; i < MAXIMUM_NAME_LENGTH - cusLastName.length(); i++)
			{
				addCusLastName += "X";
			}
			customerID = cusLastName + addCusLastName + "-";
		}
		else
		{
			customerID = cusLastName.substring(0,4) + "-";
		}
		
		//add 5 random digits after the name
		for(int i = 0; i < CUSTOMER_ID_NUMBER; i++)
		{
			customerID += (int)(Math.random() * 10);
		}
	}//End of setCustomerID()

	/**
	 * Sets the customerLevel of this object
	 * @param customerLevel - the value to set
	 */
	public void setCustomerLevel(String customerLevel)
	{
		this.customerLevel = customerLevel;
	}//End of setCustomerLevel()
	
	/**
	 * An abstract method for subclasses
	 * @return double
	 */
	public abstract double incentives();
	
	/**
	 * Displays Customer object
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		return String.format("%s, %s %s\n", customerID, firstName, lastName);
	}//End of toString()
}//End of class