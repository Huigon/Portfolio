/**
 * Program Name:	CustomerTester.java
 * Purpose:			To test Customer hierarchy classes
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 16, 2021
 */

public class CustomerTester 
{
	public static void main(String[] args) 
	{
		//Display an opening message
		System.out.println("---------------------------------------------------------------------------------------");
		System.out.println("This program will instantiate objects of the Customer hierarchy and test their methods");
		System.out.println("---------------------------------------------------------------------------------------");
		
		//1. Create an array of type Customer, holding three customers
		Customer customerArray[] = new Customer[3];
		
		//2. Create three Customer objects
		BusinessCustomer customer1 = new BusinessCustomer("Zexing", "Cheng", "Business Customer", "Home Depot", 10, 3105.50);
		RetailCustomer customer2 = new RetailCustomer("Joey", "Vo", "Retail Customer", 11200.00);
		PreferredCustomer customer3 = new PreferredCustomer("Austin", "O'Neill", "Preferred Customer", 6456.85, 5);		
		
		//3. Assign each customer object to the Customer array
		customerArray[0] = customer1;
		customerArray[1] = customer2;
		customerArray[2] = customer3;
		
		//4. Print each object in the array
		for(int i = 0; i < customerArray.length; i++)
		{
			System.out.println(customerArray[i].toString());
		}
		
		//5. Print each customer's names and incentives
		for(int i = 0; i < customerArray.length; i++)
		{
			System.out.printf("%s %s earns a discount incentive of $%.2f\n", customerArray[i].getFirstName(), customerArray[i].getLastName(), customerArray[i].incentives());
		}
		System.out.println();
		
		//6. Create three more Customer objects
		BusinessCustomer customer4 = new BusinessCustomer("Aleksei", "Vandyshev", "Business Customer", "Starbucks", 15, 9875.25);
		RetailCustomer customer5 = new RetailCustomer("Matthew", "Taylor", "Retail Customer", 3100.50);
		PreferredCustomer customer6 = new PreferredCustomer("Vibhuti", "Sahdev", "Preferred Customer", 10450, 10);
		
		//7. Print three new Customer objects
		System.out.println(customer4.toString());
		System.out.println(customer5.toString());
		System.out.println(customer6.toString());
		
		//8. Change elements of Customer objects
		customer4.setTotalPurchases(8895.00);
		customer4.setDiscountRate(12);		
		customer5.setTotalPurchases(100500.00);		
		customer6.setTotalPurchases(14987.24);
		customer6.setLastName("Sahdev-Oza");
		customer6.setCashbackRate(13);
		
		//9. Print again
		System.out.println(customer4.toString());
		System.out.println(customer5.toString());
		System.out.println(customer6.toString());
	}//End of main method
}//End of class