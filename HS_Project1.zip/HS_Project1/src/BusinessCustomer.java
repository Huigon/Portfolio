/**
 * Program Name:	BusinessCustomer.java
 * Purpose:			A concrete subclass of the abstract Customer class
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 16, 2021
 */

public class BusinessCustomer extends Customer
{
	//Declare instance field
	private String companyName;
	private int discountRate;
	private double totalPurchases;
	
	/**
	 * Constructs a new BusinessCustomer object
	 * @param firstName - initializes firstName
	 * @param lastName - initializes lastName
	 * @param customerLevel - initializes customerLevel
	 * @param companyName - initializes companyName
	 * @param discountRate - initializes discountRate
	 * @param totalPurchases - initializes totalPurchases
	 */
	public BusinessCustomer(String firstName, String lastName, String customerLevel, String companyName, int discountRate, double totalPurchases)
	{
		super(firstName, lastName, customerLevel);
		this.companyName = companyName;
		this.discountRate = discountRate;
		this.totalPurchases = totalPurchases;
	}

	/**
	 * Gets the companyName of this object  
	 * @return the companyName
	 */
	public String getCompanyName()
	{
		return companyName;
	}//End of getCompanyName()

	/**
	 * Gets the discountRate of this object  
	 * @return the discountRate
	 */
	public int getDiscountRate()
	{
		return discountRate;
	}//End of getDiscountRate()

	/**
	 * Gets the totalPurchases of this object  
	 * @return the totalPurchases
	 */
	public double getTotalPurchases()
	{
		return totalPurchases;
	}//End of getTotalPurchases()

	/**
	 * Sets the companyName of this object
	 * @param name - the value to set
	 */
	public void setCompanyName(String name)
	{
		companyName = name;
	}//End of setCompanyName()

	/**
	 * Sets the discountRate of this object
	 * @param discountRate - the value to set
	 */
	public void setDiscountRate(int discountRate)
	{
		this.discountRate = discountRate;
	}//End of setCompanyName()

	/**
	 * Sets the totalPurchases of this object
	 * @param purchases - the value to set
	 */
	public void setTotalPurchases(double purchases)
	{
		totalPurchases = purchases;
	}//End of setTotalPurchases()
	
	/**
	 * Gets incentive amount according to total purchase
	 * @see Customer#incentives()
	 */
	public double incentives()
	{
		return (double)discountRate * totalPurchases / 100;
	}//End of incentives()
	
	/**
	 * Displays BusinessCustomer object
	 * @see Customer#toString()
	 */
	public String toString()
	{
		return super.toString()
				+ String.format("%s for %s\n", super.getCustomerLevel(), companyName)
				+ String.format("%-20s $%,.2f\n", "Total Purchases:", totalPurchases)
				+ String.format("%-20s %d%%\n", "Discount Rate:", discountRate)
				+ String.format("%-20s $%,.2f\n", "Discount Incentive:", incentives())
				+ String.format("%-20s $%,.2f\n", "Net Purchases:", totalPurchases - incentives());
	}//End of toString()
}//End of class