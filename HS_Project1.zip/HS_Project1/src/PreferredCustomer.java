/**
 * Program Name:	PreferredCustomer.java
 * Purpose:			A subclass of RetailCustomer
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 16, 2021
 */

public class PreferredCustomer extends RetailCustomer
{
	//Declare instance field
	private int cashbackRate;
	
	/**
	 * Constructs a new PreferredCustomer object
	 * @param firstName - initializes firstName
	 * @param lastName - initializes lastName
	 * @param customerLevel - initializes customerLevel
	 * @param totalPurchases - initializes totalPurchases
	 * @param cashbackRate - initializes cashbackRate
	 */
	public PreferredCustomer(String firstName, String lastName, String customerLevel, double totalPurchases, int cashbackRate)
	{
		super(firstName, lastName, customerLevel, totalPurchases);
		this.cashbackRate = cashbackRate;
	}

	/**
	 * Gets the cashbackRate of this object  
	 * @return the cashbackRate
	 */
	public int getCashbackRate()
	{
		return cashbackRate;
	}//End of getCashbackRate()

	/**
	 * Sets the cashbackRate of this object
	 * @param cashBack - the value to set
	 */
	public void setCashbackRate(int cashBack)
	{
		cashbackRate = cashBack;
	}//End of setCashbackRate()
	
	/**
	 * Gets incentive amount according to total purchase and cashback rate
	 * @see RetailCustomer#incentives()
	 */
	public double incentives()
	{
		//( Incentive earned by a Retail Customer ) * ( 1 + cashbackRate(converted to a double) )
		return (super.getTotalPurchases() * super.findDiscoutRate() / 100) * (1 + (double)cashbackRate / 100);	
	}//End of incentives()
	
	/**
	 * Displays PreferredCustomer object
	 * @see RetailCustomer#toString()
	 */
	public String toString()
	{
		return super.toString()
				+ String.format("%-20s %d%%\n", "Cashback Rate:", cashbackRate);
	}//End of toString()
}//End of class