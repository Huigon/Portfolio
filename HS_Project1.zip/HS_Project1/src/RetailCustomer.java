/**
 * Program Name:	RetailCustomer.java
 * Purpose:			A concrete subclass of the abstract Customer class
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 16, 2021
 */

public class RetailCustomer extends Customer
{
	//Declare instance field
	private double totalPurchases;
	
	/**
	 * Constructs a new RetailCustomer object
	 * @param firstName - initializes firstName
	 * @param lastName - initializes lastName
	 * @param customerLevel - initializes customerLevel
	 * @param totalPurchases - initializes totalPurchases
	 */
	public RetailCustomer(String firstName, String lastName, String customerLevel, double totalPurchases)
	{
		super(firstName, lastName, customerLevel);
		this.totalPurchases = totalPurchases;
	}

	/**
	 * Gets the totalPurchases of this object  
	 * @return the totalPurchases
	 */
	public double getTotalPurchases()
	{
		return totalPurchases;
	}//End of getTotalPurchases()

	/**
	 * Sets the totalPurchases of this object
	 * @param purchases - the value to set
	 */
	public void setTotalPurchases(double purchases)
	{
		totalPurchases = purchases;
	}//End of setTotalPurchases()
	
	/**
	 * Gets discount rate according to total purchase
	 * @return discount rate
	 */
	public int findDiscoutRate()
	{
		//Declare constants
		final int PURCHASE_FOR_DISCOUNT_RATE_15 = 10000;
		final int PURCHASE_FOR_DISCOUNT_RATE_10 = 5000;
		final int PURCHASE_FOR_DISCOUNT_RATE_5 = 1000;
		
		//Find discount rate according to a total purchase
		if(totalPurchases > PURCHASE_FOR_DISCOUNT_RATE_15)
		{
			return 15;
		}
		else if(totalPurchases > PURCHASE_FOR_DISCOUNT_RATE_10)
		{
			return 10;
		}
		else if(totalPurchases > PURCHASE_FOR_DISCOUNT_RATE_5)
		{
			return 5;
		}
		else
		{
			return 0;
		}
	}//End of findDiscoutRate()
	
	/**
	 * Gets incentive amount according to total purchase
	 * @see Customer#incentives()
	 */
	public double incentives()
	{
		return (double)findDiscoutRate() * totalPurchases / 100;
	}//End of incentives()
	
	/**
	 * Displays RetailCustomer object
	 * @see Customer#toString()
	 */
	public String toString()
	{
		return super.toString()
				+ String.format("%s\n", super.getCustomerLevel())
				+ String.format("%-20s $%,.2f\n", "Total Purchases:", totalPurchases)
				+ String.format("%-20s %d%%\n", "Discount Rate:", findDiscoutRate())
				+ String.format("%-20s $%,.2f\n", "Discount Incentive:", incentives())
				+ String.format("%-20s $%,.2f\n", "Net Purchases:", totalPurchases - incentives());	
	}//End of toString()
}//End of class