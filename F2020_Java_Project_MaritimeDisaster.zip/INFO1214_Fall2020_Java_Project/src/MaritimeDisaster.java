/**
 * Program Name:		MaritimeDisaster.java
 * Purpose:				To get quick explanation for users to analyze the Maritime Disaster
 * @author				Huigon Shin, 1030403
 * Date:   		 		Dec 7, 2020
 */

import java.io.*;

public class MaritimeDisaster 
{
	public static void main(String[] args) throws IOException
	{
		//Declare and initialize variables
		String [][] passengers = MaritimeHelper.buildPassengerArray("Titanic_Passengers.csv");
		int userChoice = 0;
				
		//Display a title box of the application
		MaritimeHelper.printTitleBox();
		
		//Display a list of options
		MaritimeHelper.printOptions();
		
		//Obtain an user option
		userChoice = MaritimeHelper.getOption();
		
		//Output a result depending on an user option
		while(userChoice != 0)
		{
			switch(userChoice)
			{
				case 1: MaritimeHelper.printPassengersTable(passengers);
						break;
				case 2: MaritimeHelper.printPassengersByClassAndGender(passengers);
						break;
				case 3: MaritimeHelper.printSurvivorsByClassAndGender(passengers);
						break;
				case 4: MaritimeHelper.printVictimsByClassAndGender(passengers);
						break;
				case 5: MaritimeHelper.printSurvivalRateByClassAndGender(passengers);
						break;
				default: MaritimeHelper.printSurvivorOrVicitimCountByAgeRange(passengers);
						break;
			}
			MaritimeHelper.printOptions();
			userChoice = MaritimeHelper.getOption();
		}	
	}//End of main method
}//End of class