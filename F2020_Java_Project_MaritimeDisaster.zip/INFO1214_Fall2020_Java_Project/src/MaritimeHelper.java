/**
 * Program Name:		MaritimeHelper.java
 * Purpose:				To make methods for main method called HS_Maritime_Analysis, reducing the amount of code in the main method
 * @author				Huigon Shin, 1030403
 * Date:   		 		Dec 7, 2020
 */

import java.util.Scanner;
import java.io.*;

public class MaritimeHelper
{
	//Create a Scanner class for user input
	public static Scanner input = new Scanner(System.in); 
	
	//Method to assign variables to 2D array from the file
	public static String [][] buildPassengerArray(String filename) throws IOException
	{
		File file = new File(filename);
		Scanner read = new Scanner(file);
		
		int [] rowAndColumn = countFileData(filename);
		String [][] table = new String[rowAndColumn[0]][rowAndColumn[1]];
		
		for(int i = 0; i < table.length; i++)
		{
			String line = read.nextLine();
			table[i] = line.split(",");
		}		
		read.close();
		
		return table;
	}
		
	//Method to obtain an array with the number of rows and columns of the file
	public static int [] countFileData(String filename) throws IOException
	{
		File file = new File(filename);
		Scanner read = new Scanner(file);
			
		int [] array = new int[2];
		int counter = 1;			//counting starts at the second line
		String firstLine = read.nextLine();
		String [] separatedLine = firstLine.split(",");
		
		while(read.hasNextLine())
		{
			read.nextLine();
			counter++;
		}
		
		array[0] = counter;		
		array[1] = separatedLine.length;
		
		read.close();
				
		return array;
	}	
	
	//Method to display a title box of the application
	public static void printTitleBox()
	{
		System.out.println("-------------------------------------------------------------------------");
		System.out.println("Welcome to Huigon Shin's Maritime Disaster Analysis Application");
		System.out.println("-------------------------------------------------------------------------");
		System.out.println("We are analyzing the maritime disaster involving the ship RMS Titanic.");
		System.out.println("The name of the file holding the data is \"Titanic_Passengers.csv\".");
		System.out.println("Now opening the file and creating the data table...");
		System.out.println("-------------------------------------------------------------------------");
		System.out.println("The data has been loaded into the table for analysis.");
		System.out.println("Here is a list of options for analyzing the data.");			
	}
	
	//Method to display a list of options
	public static void printOptions()
	{
		System.out.println("Select an option using an integer number between 1-6, or enter 0 to exit.");
		System.out.println("-------------------------------------------------------------------------");
		System.out.printf("%-9s %-54s\n", "Enter 1:", "To see a complete listing of all passengers");
		System.out.printf("%-9s %-54s\n", "Enter 2:", "To get a count of passengers by class AND gender");
		System.out.printf("%-9s %-54s\n", "Enter 3:", "To get a count of survivors by class AND gender");
		System.out.printf("%-9s %-54s\n", "Enter 4:", "To get a count of victims by class AND gender");
		System.out.printf("%-9s %-54s\n", "Enter 5:", "To get a percentage survival rate by class and gender");
		System.out.printf("%-9s %-54s\n", "Enter 6:", "To get a count of survivors or victims by range of age");
		System.out.printf("%-9s %-54s\n", "Enter 0:", "To exit the program");
		System.out.print("\nEnter your option selection: ");
	}
	
	//Method to obtain user option with input validation
	public static int getOption()
	{
		int number = 0;
			
		while(true)
		{
			if(!input.hasNextInt())
			{
				System.out.print("Error, input is not integer, re-enter: ");
			}
			else
			{
				number = input.nextInt();
				if(number >= 0 && number <= 6)
				{					
					break;
				}
				System.out.print("Error, re-enter (0 - 6): ");									
			}
			input.nextLine();
		}		
		return number;
	}
	
	//Method to print the first option
	public static void printPassengersTable(String [][] array)
	{
		System.out.println("\nThe passenger list for the RMS Titanic:\n");
		for(int i = 0; i < array.length; i++)
		{
			for(int j = 0; j < array[i].length; j++)
			{
				System.out.printf("%-26s", array[i][j]);
			}
			System.out.println();
		}
		System.out.println();
	}
	
	//Method to print the second option
	public static void printPassengersByClassAndGender(String [][] array)
	{
		String className = "";
		String gender = "";
		String passenger = "passengers";
		int numPassenger = 0;
		
		className = getTicketClass();
		gender = getGender();		
		numPassenger = getPassengersByClassAndGender(array, gender, className);
		
		printForThreeOptions(gender, className, passenger, numPassenger);
	}
	
	//Method to print the third option
	public static void printSurvivorsByClassAndGender(String [][] array)
	{
		String className = "";
		String gender = "";
		String passenger = "survivors";
		int numSurvivor = 0;
					
		className = getTicketClass();
		gender = getGender();		
		numSurvivor = getSurvivorsByClassAndGender(array, gender, className);
		
		printForThreeOptions(gender, className, passenger, numSurvivor);
	}
	
	//Method to print the fourth option
	public static void printVictimsByClassAndGender(String [][] array)
	{
		String className = "";
		String gender = "";
		String passenger = "victims";
		int numVictim = 0;
					
		className = getTicketClass();
		gender = getGender();		
		numVictim = getVictimsByClassAndGender(array, gender, className);
		
		printForThreeOptions(gender, className, passenger, numVictim);
	}
	
	//Method to print the fifth option
	public static void printSurvivalRateByClassAndGender(String [][] array)
	{
		String className = "";
		String gender = "";		
		double survivalRate = 0.0; 
		
		className = getTicketClass();
		gender = getGender();						
		survivalRate = getSurvivalRateByClassAndGender(array, gender, className);

		System.out.printf("\n***The percentage survival rate for %s passengers in %s is %.2f%%.\n\n", gender, className, survivalRate);		
	}
	
	//Method to print the sixth option
	public static void printSurvivorOrVicitimCountByAgeRange(String [][] array)
	{
		String survival = "";
		String passenger = "";
		double [] ageArray = new double[array.length];
		int ageUpper = 0;
		int ageLower = 0;
		int numPassenger = 0;
		
		survival = getSurvival();
		passenger = survival.equals("yes") ? "survivors" : "victims";
		
		ageLower = getLowerAge();
		ageUpper = getUpperAge();
		
		if(ageUpper < ageLower)
		{
			int temp = ageUpper;
			ageUpper = ageLower;
			ageLower = temp;
		}		
		
		ageArray = getArrayAgeStringToDouble(array);				
		numPassenger = getSurvivorOrVicitimCountByAgeRange(array, ageArray, ageLower, ageUpper, survival);
		
		System.out.printf("\n***The number of %s in age between %d and %d was %d\n\n", passenger, ageLower, ageUpper, numPassenger);		
	}
	
	//Method to obtain lower range of age from user input
	public static int getLowerAge()
	{
		int ageLower = 0;
		
		System.out.print("Enter the lower end of age for search (0 - 80): ");
				
		while(true)
		{
			if(!input.hasNextInt())
			{
				System.out.print("Error, input is not integer, re-enter: ");
			}
			else
			{
				ageLower = input.nextInt();
				if(ageLower >= 0 && ageLower <= 80)
				{					
					break;
				}
				System.out.print("Error, re-enter (0 - 80): ");									
			}
			input.nextLine();
		}		
		return ageLower;
	}
	
	//Method to obtain upper range of age from user input
	public static int getUpperAge()
	{
		int ageUpper = 0;
		
		System.out.print("Enter the upper end of age for search (0 - 80): ");		
		
		while(true)
		{
			if(!input.hasNextInt())
			{
				System.out.print("Error, input is not integer, re-enter: ");
			}
			else
			{
				ageUpper = input.nextInt();
				if(ageUpper >= 0 && ageUpper <= 80)
				{					
					break;
				}
				System.out.print("Error, re-enter (0 - 80): ");									
			}
			input.nextLine();
		}		
		return ageUpper;
	}
	
	//Method to obtain a class from user input
	public static String getTicketClass()
	{
		System.out.print("Enter ticket class for search (1st, 2nd, or 3rd): ");		
		String className = input.next().toLowerCase();		
		
		while(!(className.equals("1st") || className.equals("2nd") || className.equals("3rd")))
		{
			System.out.print("Error, re-enter (1st, 2nd, or 3rd): ");
			className = input.next().toLowerCase();
		}
		input.nextLine();
		return className;
	}
	
	//Method to obtain gender from user input
	public static String getGender()
	{
		System.out.print("Enter gender for search (female or male): ");		
		String gender = input.next().toLowerCase();
		
		while(!(gender.equals("female") || gender.equals("male")))
		{
			System.out.print("Error, re-enter (female or male): ");
			gender = input.next().toLowerCase();
		}
		return gender;
	}
	
	//Method to obtain whether survived or not from user input
	public static String getSurvival()
	{
		System.out.print("Enter survival for search (yes or no): ");
		String survival = input.next().toLowerCase();
		
		while(!(survival.equals("yes") || survival.equals("no")))
		{
			System.out.print("Error, re-enter (yes or no): ");
			survival = input.next().toLowerCase();
		}
		return survival;
	}
	
	//Method to obtain the number of people by the class and gender from user input
	public static int getPassengersByClassAndGender(String [][] array, String gender, String className)
	{
		int counter = 0;
		
		final int GENDER_INDEX = 3;
		final int CLASS_INDEX = 5;
		
		for(int i = 0; i < array.length; i++)
		{
			if(array[i][GENDER_INDEX].equals(gender) && array[i][CLASS_INDEX].equals(className))
			{
				counter++;
			}			
		}
		return counter;
	}
	
	//Method to obtain the number of survivors by the class and gender from user input
	public static int getSurvivorsByClassAndGender(String [][] array, String gender, String className)
	{
		int counter = 0;
		String survival = "yes";
		
		final int SURVIVAL_INDEX = 2;
		final int GENDER_INDEX = 3;
		final int CLASS_INDEX = 5;
		
		for(int i = 0; i < array.length; i++)
		{
			if(array[i][GENDER_INDEX].equals(gender) && array[i][CLASS_INDEX].equals(className) && array[i][SURVIVAL_INDEX].equals(survival))
			{
				counter++;
			}			
		}
		return counter;
	}
	
	//Method to obtain the number of victims by the class and gender from user input
	public static int getVictimsByClassAndGender(String [][] array, String gender, String className)
	{
		int counter = 0;
		String survival = "no";
		
		final int SURVIVAL_INDEX = 2;
		final int GENDER_INDEX = 3;
		final int CLASS_INDEX = 5;
		
		for(int i = 0; i < array.length; i++)
		{
			if(array[i][GENDER_INDEX].equals(gender) && array[i][CLASS_INDEX].equals(className) && array[i][SURVIVAL_INDEX].equals(survival))
			{
				counter++;
			}			
		}
		return counter;
	}
	
	//Method to obtain a survival percentage of passengers by gender and class
	public static double getSurvivalRateByClassAndGender(String [][] array, String gender, String className)
	{
		int totalCounter = 0;
		int survivalCounter = 0;
		double survivalRate = 0.0;
		
		totalCounter = getPassengersByClassAndGender(array, gender, className);
		survivalCounter = getSurvivorsByClassAndGender(array, gender, className);
		
		survivalRate = survivalCounter * 100.0 / totalCounter;
		
		return survivalRate;
	}
	
	
	
	//Method to obtain the number of survivors or victims by the class and gender from user input
	public static int getSurvivorOrVicitimCountByAgeRange(String [][] array, double [] ageArray, int ageLower, int ageUpper, String survival)
	{
		int counter = 0;
		
		final int SURVIVAL_INDEX = 2;
		
		for(int i = 1; i < array.length; i++)
		{
			if(array[i][SURVIVAL_INDEX].equals(survival) && (ageArray[i] >= ageLower && ageArray[i] <= ageUpper))
			{
				counter++;
			}
		}
		return counter;
	}
		
	//Method to obtain a new array from age column in the file, changing String values to double values
	public static double [] getArrayAgeStringToDouble(String [][] array)
	{
		String exception = "NA";
		double [] ageArray = new double[array.length];
		
		final int AGE_INDEX = 4;
		
		for(int i = 1; i < array.length; i++)
		{
			if(array[i][AGE_INDEX].equals(exception))		//all "NA" values go to negative values (-1) in ageArray to ignore when counting 
			{
				ageArray[i] = -1;
			}
			else
			{
				ageArray[i] = Double.parseDouble(array[i][AGE_INDEX]);	
			}			
		}
		return ageArray;
	}	
	
	//Method to print results for 2nd, 3rd, and 4th option 
	public static void printForThreeOptions(String gender, String className, String passenger, int numPeople)
	{
		System.out.printf("\n***The number of %s %s in %s class was %d\n\n", gender, passenger, className, numPeople);		
	}	
}//End of class