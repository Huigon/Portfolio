/**
 * Program Name:	LongOperandException.java
 * Purpose:			An exception class which will throw an exception if an operand is too long for the text field display area
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Apr 6, 2021
 */

public class LongOperandException extends Exception
{
	/**
	 * Constructs a new LongOperandException object
	 */
	public LongOperandException()
	{
		super("Warning: operand is too long.");
	}
}//End of class