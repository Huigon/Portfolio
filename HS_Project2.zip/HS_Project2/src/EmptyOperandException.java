/**
 * Program Name:	EmptyOperandException.java
 * Purpose:			An exception class which will throw an exception if no operand has been entered
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Apr 6, 2021
 */

public class EmptyOperandException extends Exception
{
	/**
	 * Constructs a new EmptyOperandException object
	 */
	public EmptyOperandException()
	{
		super("Warning: operand is empty.");
	}
}//End of class