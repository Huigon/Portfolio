/**
 * Program Name:	Calculator.java
 * Purpose:			A class to be used to create a Calculator object
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Apr 6, 2021
 */

import java.util.ArrayList;

public class Calculator 
{
	//Declare instance fields
	private String operand;
	private String operator;
	private boolean decimalPressed;
	private ArrayList<String> list;
	
	/**
	 * Constructs a new Calculator object
	 */
	public Calculator()
	{
		operand = "";
		operator = "";
		decimalPressed = false;
		list = new ArrayList<String>();
	}

	/**
	 * Gets the operand of this object  
	 * @return the operand
	 */
	public String getOperand()
	{
		return operand;
	}//End of getOperand()

	/**
	 * Gets the operator of this object  
	 * @return the operator
	 */
	public String getOperator()
	{
		return operator;
	}//End of getOperator()

	/**
	 * Gets the decimalPressed of this object  
	 * @return the decimalPressed
	 */
	public boolean isDecimalPressed()
	{
		return decimalPressed;
	}//End of isDecimalPressed()

	/**
	 * Sets the operand of this object
	 * @param operand - the value to set
	 */
	public void setOperand(String operand)
	{
		this.operand = operand;
	}//End of setOperand()

	/**
	 * Sets the operator of this object
	 * @param operator - the value to set
	 */
	public void setOperator(String operator)
	{
		this.operator = operator;
	}//End of setOperator()

	/**
	 * Sets the decimalPressed of this object
	 * @param decimalPressed - the value to set
	 */
	public void setDecimalPressed(boolean decimalPressed)
	{
		this.decimalPressed = decimalPressed;
	}//End of setDecimalPressed()

	/**
	 * Resets all fields to default values
	 */
	public void clear()
	{
		operand = "";
		operator = "";
		decimalPressed = false;
		list = new ArrayList<String>();
	}//End of clear()
	
	/**
	 * Gets operand removed the last digit
	 * @param value - the value to set
	 * @return operand that one digit is removed at the end
	 * @throws EmptyOperandException
	 */
	public String backspace(String value) throws EmptyOperandException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		return value.substring(0, value.length() - 1); 
	}//End of backspace()
	
	/**
	 * Gets operand as a percentage in decimal format
	 * @param value - the value to set
	 * @return operand as a percentage in decimal format
	 * @throws EmptyOperandException
	 */
	public String findPercentage(String value) throws EmptyOperandException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		double doubleValue = Double.parseDouble(value);
		
		return Double.toString(doubleValue / 100);
	}//End of findPercentage()
	
	/**
	 * Makes operand positive to negative or vice versa
	 * @param flag - the value to set
	 * @return operand that converted to negative or positive
	 * @throws EmptyOperandException
	 */
	public String togglePlusMinus(boolean flag) throws EmptyOperandException
	{
		if(operand.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		if(flag == false)
			operand = "-" + operand;			
		else
			operand = operand.substring(1);
		
		return operand;
	}//End of togglePlusMinus()
	
	/**
	 * Gets squared value
	 * @param value - the value to set
	 * @return squared value
	 * @throws EmptyOperandException
	 */
	public String findSquared(String value) throws EmptyOperandException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		return Double.toString(Math.pow(Double.parseDouble(value), 2));
	}//End of findSquared()
	
	/**
	 * Gets square root of value
	 * @param value - the value to set
	 * @return square root of value
	 * @throws EmptyOperandException
	 */
	public String findSquareRoot(String value) throws EmptyOperandException, ArithmeticException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		if(Double.parseDouble(value) < 0)
		{
			throw new ArithmeticException();
		}
		
		return Double.toString(Math.sqrt(Double.parseDouble(value)));
	}//End of findSquareRoot()
	
	/**
	 * Concatenates value to operand
	 * @param value - the value to set
	 * @throws LongOperandException
	 */
	public void buildOperand(String value) throws LongOperandException
	{
		operand += value;

		if(operand.length() > 19)
		{
			operand = "";
			throw new LongOperandException();
		}
	}//End of buildOperand()
	
	/**
	 * Sets operand and operator
	 * @param value - the value to set
	 * @throws EmptyOperandException
	 */
	public void buildExpression(String value) throws EmptyOperandException
	{
		if(operand.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		operator = value;
		list.add(operand);
		list.add(operator);
		
		operand = "";
		operator = "";
		decimalPressed = false;
	}//End of buildExpression()
	
	/**
	 * Calculates current expression
	 * @return calculated result
	 * @throws EmptyOperandException
	 * @throws ArithmeticException
	 */
	public double calculate() throws EmptyOperandException, ArithmeticException
	{
		if(operand.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		list.add(operand);
		System.out.println(toString());
		
		//For multiplication and division
		boolean isOperator = false;		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i) == "*" || list.get(i) == "/")
			{
				isOperator = true;
				break;
			}	
		}
		
		while(isOperator)
		{			
			for(int i = 0; i < list.size(); i++)
			{
				if(list.get(i) == "*" || list.get(i) == "/")
				{
					if(list.get(i) == "*")
					{
						String multi = Double.toString(Double.parseDouble(list.get(i - 1)) * Double.parseDouble(list.get(i + 1)));
						list.set(i - 1, multi);
					}
					else if(list.get(i) == "/")
					{
						if(Double.parseDouble(list.get(i + 1)) == 0)
						{
							throw new ArithmeticException();
						}
							
						String div = Double.toString(Double.parseDouble(list.get(i - 1)) / Double.parseDouble(list.get(i + 1)));
						list.set(i - 1, div);
					}
					list.remove(i + 1);
					list.remove(i);
					System.out.println(toString());
					break;
				}
			}
			
			isOperator = false;		
			for(int i = 0; i < list.size(); i++)
			{
				if(list.get(i) == "*" || list.get(i) == "/")
				{
					isOperator = true;
					break;
				}	
			}
		}
		
		//For addition and subtraction
		isOperator = false;		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i) == "+" || list.get(i) == "-")
			{
				isOperator = true;
				break;
			}	
		}		
		
		while(isOperator)
		{			
			for(int i = 0; i < list.size(); i++)
			{
				if(list.get(i) == "+" || list.get(i) == "-")
				{
					if(list.get(i) == "+")
					{
						String add = Double.toString(Double.parseDouble(list.get(i - 1)) + Double.parseDouble(list.get(i + 1)));
						list.set(i - 1, add);
					}
					else if(list.get(i) == "-")
					{
						String sub = Double.toString(Double.parseDouble(list.get(i - 1)) - Double.parseDouble(list.get(i + 1)));
						list.set(i - 1, sub);
					}
					list.remove(i + 1);
					list.remove(i);
					System.out.println(toString());
					break;
				}	
			}
			
			isOperator = false;		
			for(int i = 0; i < list.size(); i++)
			{
				if(list.get(i) == "+" || list.get(i) == "-")
				{
					isOperator = true;
					break;
				}	
			}
		}
		
		double result = Double.parseDouble(list.get(0));
		clear();
		
		return result;
	}//End of calculate()
	
	/**
	 * Converts current value to hexadecimal value
	 * @param value - the value to set
	 * @return Converted hexadecimal value
	 * @throws EmptyOperandException
	 * @throws LongOperandException
	 */
	public String convertHex(String value) throws EmptyOperandException, LongOperandException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		if(value.length() > 19)
		{
			throw new LongOperandException();
		}
		
		int decimalValue = (int)(Double.parseDouble(value) + 0.5);
		String hexValue = "";
		int digits = 0;
		
		if(decimalValue == 0)
			hexValue = "0";
		
		while(decimalValue != 0)
		{
			int remainder = decimalValue % 16;

			switch(remainder)
			{
				case 0:	
					hexValue += '0';
					digits++;
					break;
				case 1: 
					hexValue += '1';
					digits++;
					break;
				case 2: 
					hexValue += '2';
					digits++;
					break;
				case 3: 
					hexValue += '3';
					digits++;
					break;
				case 4: 
					hexValue += '4';
					digits++;
					break;
				case 5: 
					hexValue += '5';
					digits++;
					break;
				case 6: 
					hexValue += '6';
					digits++;
					break;
				case 7: 
					hexValue += '7';
					digits++;
					break;
				case 8: 
					hexValue += '8';
					digits++;
					break;
				case 9: 
					hexValue += '9';
					digits++;
					break;
				case 10: 
					hexValue += 'A';
					digits++;
					break;
				case 11: 
					hexValue += 'B';
					digits++;
					break;
				case 12: 
					hexValue += 'C';
					digits++;
					break;
				case 13: 
					hexValue += 'D';
					digits++;
					break;
				case 14: 
					hexValue += 'E';
					digits++;
					break;
				case 15: 
					hexValue += 'F';
					digits++;
					break;
			}
			
			if(digits % 4 == 0 && decimalValue / 16 != 0)
			{
				hexValue += " ";
			}
			decimalValue /= 16;
		}
		
		hexValue = new StringBuilder(hexValue).reverse().toString();
		return hexValue;
	}//End of convertHex()
	
	/**
	 * Converts current value to octal decimal value
	 * @param value - the value to set
	 * @return Converted octal decimal value
	 * @throws EmptyOperandException
	 * @throws LongOperandException
	 */
	public String convertOct(String value) throws EmptyOperandException, LongOperandException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		if(value.length() > 15)
		{
			throw new LongOperandException();
		}
		
		int decimalValue = (int)(Double.parseDouble(value) + 0.5);
		String octValue = "";
		int digits = 0;
		
		if(decimalValue == 0)
			octValue = "0";
		
		while(decimalValue != 0)
		{
			int remainder = decimalValue % 8;

			switch(remainder)
			{
				case 0:	
					octValue += '0';
					digits++;
					break;
				case 1: 
					octValue += '1';
					digits++;
					break;
				case 2: 
					octValue += '2';
					digits++;
					break;
				case 3: 
					octValue += '3';
					digits++;
					break;
				case 4: 
					octValue += '4';
					digits++;
					break;
				case 5: 
					octValue += '5';
					digits++;
					break;
				case 6: 
					octValue += '6';
					digits++;
					break;
				case 7: 
					octValue += '7';
					digits++;
					break;
			}
			
			if(digits % 3 == 0 && decimalValue / 8 != 0)
			{
				octValue += " ";
			}
			decimalValue /= 8;
		}
		
		octValue = new StringBuilder(octValue).reverse().toString();
		return octValue;	
	}//End of convertOct()
	
	/**
	 * Converts current value to binary value
	 * @param value - the value to set
	 * @return Converted binary value
	 * @throws EmptyOperandException
	 * @throws LongOperandException
	 */
	public String convertBin(String value) throws EmptyOperandException, LongOperandException
	{
		if(value.isEmpty())
		{
			throw new EmptyOperandException();
		}
		
		if(value.length() > 15)
		{
			throw new LongOperandException();
		}
		
		int decimalValue = (int)(Double.parseDouble(value) + 0.5);
		String binValue = "";
		int digits = 0;
		int remainder = 0;
		
		if(decimalValue == 0)
			binValue = "0";
		
		while(decimalValue != 0)
		{
			remainder = decimalValue % 2;

			switch(remainder)
			{
				case 0:	
					binValue += '0';
					digits++;
					break;
				case 1: 
					binValue += '1';
					digits++;
					break;
			}
			
			if(digits % 4 == 0 && decimalValue / 2 != 0)
			{
				binValue += " ";
			}
			decimalValue /= 2;
		}
		
		remainder = digits % 4;
		
		switch(remainder)
		{
			case 1:	
				binValue += "000";
				break;
			case 2: 
				binValue += "00";
				break;
			case 3: 
				binValue += "0";
				break;
		}
		
		binValue = new StringBuilder(binValue).reverse().toString();
		return binValue;	
	}//End of convertBin()
	
	/**
	 * Prints current arithmetic expression
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		String output = "";
		
		for(int i = 0; i < list.size(); i++)
		{
			if(i != 0)
				output += " ";
			output += list.get(i);
		}
		
		return String.format("%s", output);
	}//End of toString()
}//End of class