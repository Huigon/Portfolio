/**
 * Program Name:	GUICalculator.java
 * Purpose:			A GUI class which instantiates a Calculator object and performs calculator operations
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Apr 6, 2021
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUICalculator extends JFrame
{
	//Declare Calculator object
	Calculator calculator;
	
	//Declare GUI components
	private JTextField txtDisplay;
	private JPanel btnPanel;
	private JButton btnClear, btnBackSpace, btnPercent, btnToggle, btnSquared, btnSqrt;
	private JButton btnMult, btnDiv, btnAdd, btnSub, btnDecimal, btnCalculate, btnEmpty1, btnEmpty2;
	private JButton [] btnNumbers;
	
	private JMenuBar mnuBar;
	private JMenu mnuFile, mnuConvert, mnuHelp;
	private JMenuItem mnuExit, mnuHowToUse, mnuAbout;
	private JRadioButtonMenuItem mnuHex, mnuDec, mnuOct, mnuBin;
	
	//Declare class variables
	private Font font;
	private ImageIcon imgClear, imgBackSpace, imgPercent, imgToggle, imgSquared, imgSqrt;
	private String decimalNum;
	private boolean isDecimalNum;
	private boolean isHexNum;
	private boolean isOctNum;
	private boolean isBinNum;
	private boolean isNegative;
	private boolean isCalculated;
	private String tempOperand;
	
	/**
	 * Constructs a new GUICalculator object
	 */
	public GUICalculator()
	{
		//Set title
		super("Calculator");
		
		//Set layout manager for JFrame
		setLayout(new BorderLayout());
		
		//Set variables
		font = new Font("SansSerif", Font.PLAIN, 22);
		decimalNum = "";
		isDecimalNum = true;
		isHexNum = false;
		isOctNum = false;
		isBinNum = false;
		isNegative = false;
		isCalculated = false;
		tempOperand = "";
		
		//Create Calculator object
		calculator = new Calculator();
		
		//Instantiate GUI components
		txtDisplay = new JTextField();
		
		//Set initial JTextField
		txtDisplay.setText("0.0");
		txtDisplay.setBackground(Color.WHITE);
		txtDisplay.setEditable(false);
		txtDisplay.setFont(font);
		txtDisplay.setHorizontalAlignment(SwingConstants.RIGHT);		
		
		//Help method for btnPanel
		buildBtnPanel();
		
		//Help method for mnuBar
		buildMenuBar();
		
		//Add components to JFrame
		add(txtDisplay, BorderLayout.NORTH);
		add(btnPanel, BorderLayout.CENTER);
		
		//Set up the frame
		setSize(300, 365);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	/**
	 * Help method for btnPanel
	 */
	private void buildBtnPanel()
	{
		//Create instance
		btnPanel = new JPanel();
		
		imgClear = new ImageIcon("clear.jpg");
		imgBackSpace = new ImageIcon("backspace.jpg");
		imgPercent = new ImageIcon("percent.jpg");
		imgToggle = new ImageIcon("toggle.jpg");
		imgSquared = new ImageIcon("squared.jpg");
		imgSqrt = new ImageIcon("sqrt.jpg");
		
		btnClear = new JButton("", imgClear);
		btnBackSpace = new JButton("", imgBackSpace);
		btnPercent = new JButton("", imgPercent);
		btnToggle = new JButton("", imgToggle);
		btnSquared = new JButton("", imgSquared);
		btnSqrt = new JButton("", imgSqrt);
		btnMult = new JButton("X");
		btnDiv = new JButton("/");
		btnAdd = new JButton("+");
		btnSub = new JButton("-");
		btnDecimal = new JButton(".");
		btnCalculate = new JButton("=");
		btnEmpty1 = new JButton();
		btnEmpty2 = new JButton();
		
		btnNumbers = new JButton[10];
		for(int i = 0; i < btnNumbers.length; i++)
		{
			btnNumbers[i] = new JButton(String.valueOf(i));
			
			//Set btnNumbers' color
			btnNumbers[i].setBackground(Color.WHITE);
		}
		
		//Set buttons' color
		btnClear.setBackground(Color.WHITE);
		btnBackSpace.setBackground(Color.WHITE);
		btnPercent.setBackground(Color.WHITE);
		btnToggle.setBackground(Color.WHITE);
		btnSquared.setBackground(Color.WHITE);
		btnSqrt.setBackground(Color.WHITE);
		btnMult.setBackground(Color.WHITE);
		btnDiv.setBackground(Color.WHITE);
		btnAdd.setBackground(Color.WHITE);
		btnSub.setBackground(Color.WHITE);
		btnDecimal.setBackground(Color.WHITE);
		btnCalculate.setBackground(Color.WHITE);
		btnEmpty1.setBackground(Color.WHITE);
		btnEmpty2.setBackground(Color.WHITE);
		
		//Set layout manager for btnPanel
		btnPanel.setLayout(new GridLayout(6,4,2,2));

		
		//Add components to btnPanel
		btnPanel.add(btnClear);	
		btnPanel.add(btnBackSpace);	
		btnPanel.add(btnPercent);	
		btnPanel.add(btnToggle);	
		btnPanel.add(btnSquared);	
		btnPanel.add(btnSqrt);	
		btnPanel.add(btnEmpty1);	
		btnPanel.add(btnDiv);			
		btnPanel.add(btnNumbers[7]);		
		btnPanel.add(btnNumbers[8]);		
		btnPanel.add(btnNumbers[9]);
		btnPanel.add(btnMult);				
		btnPanel.add(btnNumbers[4]);		
		btnPanel.add(btnNumbers[5]);		
		btnPanel.add(btnNumbers[6]);		
		btnPanel.add(btnSub);				
		btnPanel.add(btnNumbers[1]);		
		btnPanel.add(btnNumbers[2]);		
		btnPanel.add(btnNumbers[3]);		
		btnPanel.add(btnAdd);				
		btnPanel.add(btnEmpty2);				
		btnPanel.add(btnNumbers[0]);
		btnPanel.add(btnDecimal);				
		btnPanel.add(btnCalculate);			
		
		//Set font for some buttons
		btnDiv.setFont(font);
		btnMult.setFont(font);
		btnSub.setFont(font);
		btnAdd.setFont(font);
		btnDecimal.setFont(font);
		btnCalculate.setFont(font);
		for(int i = 0; i < btnNumbers.length; i++)
		{
			btnNumbers[i].setFont(font);;
		}
		
		//Add listeners to each of the buttons
		ButtonHandler numBtnHandler = new ButtonHandler();
		for(int i = 0; i < btnNumbers.length; i++)
		{
			btnNumbers[i].addActionListener(numBtnHandler);
		}
		
		//Add listeners to other buttons
		OtherButtonHandler otherBtnHandler = new OtherButtonHandler();
		btnDiv.addActionListener(otherBtnHandler);
		btnMult.addActionListener(otherBtnHandler);
		btnSub.addActionListener(otherBtnHandler);
		btnAdd.addActionListener(otherBtnHandler);
		btnDecimal.addActionListener(otherBtnHandler);
		btnCalculate.addActionListener(otherBtnHandler);
		btnClear.addActionListener(otherBtnHandler);
		btnBackSpace.addActionListener(otherBtnHandler);
		btnPercent.addActionListener(otherBtnHandler);
		btnToggle.addActionListener(otherBtnHandler);
		btnSquared.addActionListener(otherBtnHandler);
		btnSqrt.addActionListener(otherBtnHandler);
	}//End of buildBtnPanel()
	
	/**
	 * Private inner class for numeric buttons
	 */
	private class ButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			for(int i = 0; i < btnNumbers.length; i++)
			{
				if(e.getSource() == btnNumbers[i])
				{
					try
					{
						if(isCalculated == true)
							calculator.setOperand("");
						
						calculator.buildOperand(String.valueOf(i));
						isCalculated = false;
					} 
					catch (LongOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is too long.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
				}
				
				if(!calculator.getOperand().isEmpty())
					txtDisplay.setText(calculator.getOperand());
			}
		}
	}
	
	/**
	 * Private inner class for other buttons
	 */
	private class OtherButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			try
			{
				//For clear button
				if(e.getSource() == btnClear)
				{
					calculator.setOperand("");
					txtDisplay.setText("0.0");
					
					//Set to decimal number as default
					isDecimalNum = true;
					isHexNum = false;
					isOctNum = false;
					isBinNum = false;
					mnuDec.setSelected(true);
					
					calculator.setDecimalPressed(false);
					isNegative = false;
					isCalculated = false;
				}
				
				//For backspace button
				if(e.getSource() == btnBackSpace)
				{
					calculator.setOperand(calculator.backspace(calculator.getOperand()));
					
					if(calculator.getOperand().isEmpty() || (calculator.getOperand().length() == 1 && calculator.getOperand().charAt(0) == '-'))
					{
						txtDisplay.setText("0.0");
						calculator.setOperand("");
					}
					else
						txtDisplay.setText(calculator.getOperand());
				}
				
				//For percentage button
				if(e.getSource() == btnPercent)
				{
					tempOperand = calculator.getOperand();
					
					calculator.setOperand(calculator.findPercentage(tempOperand));
					txtDisplay.setText(calculator.getOperand());
					System.out.println(String.format("%s as %% = %s", tempOperand, calculator.getOperand()));
					
					isNegative = false;
					isCalculated = true;
				}
				
				//For toggle button
				if(e.getSource() == btnToggle)
				{
					calculator.setOperand(calculator.togglePlusMinus(isNegative));
					txtDisplay.setText(calculator.getOperand());
					
					if(isNegative == false)
						isNegative = true;
					else
						isNegative = false;
				}
				
				//For squared button
				if(e.getSource() == btnSquared)
				{
					tempOperand = calculator.getOperand();
					
					calculator.setOperand(calculator.findSquared(calculator.getOperand()));
					txtDisplay.setText(calculator.getOperand());
					System.out.println(String.format("%s as squared = %s", tempOperand, calculator.getOperand()));
					
					isNegative = false;
					isCalculated = true;
				}
				
				//For square root button
				if(e.getSource() == btnSqrt)
				{
					tempOperand = calculator.getOperand();
					
					calculator.setOperand(calculator.findSquareRoot(calculator.getOperand()));			
					txtDisplay.setText(calculator.getOperand());
					System.out.println(String.format("%s as square root = %s", tempOperand, calculator.getOperand()));
					
					isCalculated = true;
				}
				
				//For Multiplication button
				if(e.getSource() == btnMult)
				{
					calculator.buildExpression("*");
					System.out.println(calculator.toString());
					
					isNegative = false;
				}
				
				//For division button
				if(e.getSource() == btnDiv)
				{
					calculator.buildExpression("/");
					System.out.println(calculator.toString());
					
					isNegative = false;
				}
				
				//For addition button
				if(e.getSource() == btnAdd)
				{
					calculator.buildExpression("+");
					System.out.println(calculator.toString());	
					
					isNegative = false;
				}
				
				//For subtraction button
				if(e.getSource() == btnSub)
				{
					calculator.buildExpression("-");
					System.out.println(calculator.toString());	
					
					isNegative = false;
				}
				
				//For decimal point button
				if(e.getSource() == btnDecimal)
				{
					if(calculator.isDecimalPressed() == false && !calculator.getOperand().isEmpty())
					{
						calculator.buildOperand(".");
						calculator.setDecimalPressed(true);
					}
				}
				
				//For calculation button
				if(e.getSource() == btnCalculate)
				{
					double result = calculator.calculate();
					calculator.setOperand(Double.toString(result));
					txtDisplay.setText(Double.toString(result));
					calculator.setDecimalPressed(false);
					isNegative = false;
					isCalculated = true;
				}
			}
			catch(LongOperandException exception)
			{
				txtDisplay.setText("0.0");
				System.out.println(exception.getMessage());
				JOptionPane.showMessageDialog(null, "Warning: Operand is too long.", "Alert", JOptionPane.ERROR_MESSAGE);
			}
			catch(EmptyOperandException exception)
			{
				txtDisplay.setText("0.0");
				System.out.println(exception.getMessage());
				JOptionPane.showMessageDialog(null, "Warning: Operand is empty.", "Alert", JOptionPane.ERROR_MESSAGE);
			}
			catch(ArithmeticException exception)
			{
				txtDisplay.setText("0.0");
				calculator.setOperand("");
				System.out.println("Warning: Wrong expression.");
				JOptionPane.showMessageDialog(null, "Warning: Wrong expression.", "Alert", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	/**
	 * Help method for mnuBar
	 */
	private void buildMenuBar()
	{
		//Create instance for JMenuBar
		mnuBar = new JMenuBar();
		
		//Help methods for JMenu
		buildFileMenu();
		buildConvertMenu();
		buildHelpMenu();
		
		//Add JMenu
		mnuBar.add(mnuFile);
		mnuBar.add(mnuConvert);
		mnuBar.add(mnuHelp);
		
		//Set JMenuBar to JFrame
		setJMenuBar(mnuBar);
	}//End of buildMenuBar()
	
	/**
	 * Help method for mnuFile
	 */
	private void buildFileMenu()
	{
		//Create instances
		mnuFile = new JMenu("File");
		mnuExit = new JMenuItem("Exit");
		
		//Add ActionListener
		mnuExit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		}
		);
		
		//Add JMenuItem
		mnuFile.add(mnuExit);
	}//End of buildFileMenu()
	
	/**
	 * Help method for mnuConvert
	 */
	private void buildConvertMenu()
	{
		//Create instances
		mnuConvert = new JMenu("Convert");
		mnuHex = new JRadioButtonMenuItem("Hex");
		mnuDec = new JRadioButtonMenuItem("Dec");
		mnuOct = new JRadioButtonMenuItem("Oct");
		mnuBin = new JRadioButtonMenuItem("Bin");
		
		//Set mnuDec as default JRadioButton
		mnuDec.setSelected(true);
		
		//Create a group for JRadioButtonMenuItem
		ButtonGroup group = new ButtonGroup();
		group.add(mnuHex);
		group.add(mnuDec);
		group.add(mnuOct);
		group.add(mnuBin);
		
		//Add ActionListener
		mnuHex.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(isDecimalNum == true)
				{
					decimalNum = calculator.getOperand();
				}
					
				if(isHexNum == false)
				{
					try
					{
						txtDisplay.setText(calculator.convertHex(decimalNum));
					}
					catch (EmptyOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is empty.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
					catch (LongOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is too long.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
					
					isDecimalNum = false;
					isHexNum = true;
					isOctNum = false;
					isBinNum = false;
				}
			}
		}
		);
		
		mnuDec.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(isDecimalNum == false && !decimalNum.isEmpty())
				{
					txtDisplay.setText(decimalNum);
					
					isDecimalNum = true;
					isHexNum = false;
					isOctNum = false;
					isBinNum = false;
				}
			}
		}
		);
		
		mnuOct.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(isDecimalNum == true)
				{
					decimalNum = calculator.getOperand();
				}
				
				if(isOctNum == false)
				{
					try
					{
						txtDisplay.setText(calculator.convertOct(decimalNum));
					}
					catch (EmptyOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is empty.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
					catch (LongOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is too long.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
					
					isDecimalNum = false;
					isHexNum = false;
					isOctNum = true;
					isBinNum = false;
				}
			}
		}
		);
		
		mnuBin.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(isDecimalNum == true)
				{
					decimalNum = calculator.getOperand();
				}
				
				if(isBinNum == false)
				{
					try
					{
						txtDisplay.setText(calculator.convertBin(decimalNum));
					}
					catch (EmptyOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is empty.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
					catch (LongOperandException exception)
					{
						txtDisplay.setText("0.0");
						System.out.println(exception.getMessage());
						JOptionPane.showMessageDialog(null, "Warning: Operand is too long.", "Alert", JOptionPane.ERROR_MESSAGE);
					}
					
					isDecimalNum = false;
					isHexNum = false;
					isOctNum = false;
					isBinNum = true;
				}
			}
		}
		);
		
		//Add JRadioButtonMenuItem
		mnuConvert.add(mnuHex);
		mnuConvert.add(mnuDec);
		mnuConvert.add(mnuOct);
		mnuConvert.add(mnuBin);
	}//End of buildConvertMenu()
	
	/**
	 * Help method for mnuHelp
	 */
	private void buildHelpMenu()
	{
		//Create instances
		mnuHelp = new JMenu("Help");
		mnuHowToUse = new JMenuItem("How To Use");
		mnuAbout = new JMenuItem("About");
		
		//Add ActionListener
		mnuHowToUse.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String infoMessage = "1.Press number, operator, number,..., number in order.";
				infoMessage += "\n2.Then press equal(=) button to calculate.";
				infoMessage += "\n3.Press (+/-) button to make a number negative or positive.";
				infoMessage += "\n4.Press (C) button to clear current number.";
				infoMessage += "\n5.Press backspace button to remove ONE digit at the end.";
				infoMessage += "\n6.Make number percentage, squared, square root by pressingcorresponding button.";
				infoMessage += "\n7.Make current number hexadecimal, octal, decimal, or binary in Convert menu.";
				
				JOptionPane.showMessageDialog(null, infoMessage, "How To Use", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		);
		
		mnuAbout.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(null, "Developer: Huigon Shin\n(h_shin141250@fanshaweonline.ca)", "About", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		);
		
		//Add JMenuItem
		mnuHelp.add(mnuHowToUse);
		mnuHelp.add(mnuAbout);
	}//End of buildHelpMenu()
	
	private static void setLookAndFeel()
	{
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		}	
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}//End of setLookAndFeel()
	
	public static void main(String[] args) 
	{
		setLookAndFeel();
		
		GUICalculator frame = new GUICalculator();
	}//End of main method
}//End of class