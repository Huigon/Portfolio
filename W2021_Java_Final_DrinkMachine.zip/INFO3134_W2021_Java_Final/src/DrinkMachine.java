/**
 * Program Name:	DrinkMachine.java
 * Purpose:			To create an application that simulates a soft drink vending machine
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Apr 23, 2021
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DrinkMachine extends JFrame
{
	//Declare GUI components
	private JPanel menuPanel, displayPanel;
	private JRadioButton optCoke, optSprite, optFanta, optMountainDew, optRootBeer;
	private JLabel lblPayment, lblChange;
	private JTextField txtPayment, txtChange, txtMessage;
	
	private ButtonGroup group;
	private SoftDrink [] array;
	private int index;
	private boolean isEmptyMachine;
	private double userPayment;
	private double paymentChange;
	
	/**
	 * Constructs a new DrinkMachine object
	 * @param array
	 */
	public DrinkMachine(SoftDrink []  array)
	{
		//Set title
		super("Huigon's Drink Vending Machine");
		
		//Set layout manager for JFrame
		this.setLayout(new GridLayout(2,1,5,5));
		
		//Initialize class variables
		this.array = array;
		index = 0;
		isEmptyMachine = true;
		userPayment = 0.0;
		paymentChange = 0.0;
		
		//Call methods to build panels
		buildMenuPanel();
		buildDisplayPanel();
		
		//Add components
		this.add(menuPanel);
		this.add(displayPanel);
		
		//Set up methods for the frame
		setSize(450, 275);
		setLocationRelativeTo(null);    
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true); 
	}//End of constructor
	
	//Helper method for menuPanel
	private void buildMenuPanel()
	{
		//Create panel
		menuPanel = new JPanel();
		menuPanel.setLayout(new FlowLayout());
		menuPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK, 1), "Select Your Soft Drink"));
		
		//Create GUI components
		optCoke = new JRadioButton("Coke - $1.25");
		optSprite = new JRadioButton("Sprite - $2.20");
		optFanta = new JRadioButton("Fanta Orange - $1.20");
		optMountainDew = new JRadioButton("Mountain Dew - $2.35");
		optRootBeer = new JRadioButton("Root Beer - $1.35");
		
		//Add JRadioButton to a group
		group = new ButtonGroup();
		group.add(optCoke);		
		group.add(optSprite);
		group.add(optFanta);	
		group.add(optMountainDew);	
		group.add(optRootBeer);	
		
		//Add ItemListener
		optCoke.addItemListener(new DrinkPurchaseListener());
		optSprite.addItemListener(new DrinkPurchaseListener());
		optFanta.addItemListener(new DrinkPurchaseListener());
		optMountainDew.addItemListener(new DrinkPurchaseListener());
		optRootBeer.addItemListener(new DrinkPurchaseListener());
		
		//Add components to menuPanel
		menuPanel.add(optCoke);
		menuPanel.add(optSprite);
		menuPanel.add(optFanta);
		menuPanel.add(optMountainDew);
		menuPanel.add(optRootBeer);
	}//End of buildMenuPanel()
	
	//Private inner class for JRadioButton
	private class DrinkPurchaseListener implements ItemListener
	{
		public void itemStateChanged(ItemEvent e)
		{
			//Check if machine is empty using helper method
			checkMachineEmpty();
			
			//If machine is empty
			if(isEmptyMachine == true)
			{
				group.clearSelection();
				txtPayment.setText("");
				txtChange.setText("");
				txtMessage.setText("This soft drink vending machine is empty.");
			}
			else
			{
				//Check what option chosen
				if(optCoke.isSelected())
				{
					index = 0;
				}
				else if(optSprite.isSelected())
				{
					index = 1;
				}
				else if(optFanta.isSelected())
				{
					index = 2;
				}
				else if(optMountainDew.isSelected())
				{
					index = 3;
				}
				else if(optRootBeer.isSelected())
				{
					index = 4;
				}
				
				//Check selected option is empty
				if(array[index].getQuantity() == 0)
				{
					group.clearSelection();
					txtPayment.setText("");
					txtChange.setText("");
					txtMessage.setText("This soft drink is out of stock. Choose another.");
				}
				else
				{
					txtPayment.setText("");
					txtChange.setText("");
					txtMessage.setText(array[index].toString());
				}
			}
		}
		
		//Helper method to check if machine is empty
		private void checkMachineEmpty()
		{
			isEmptyMachine = true;
			
			//Check if machine is empty
			for(int i = 0; i < array.length; i++)
			{
				if(array[i].getQuantity() != 0)
				{
					isEmptyMachine = false;
				}
			}
		}//End of checkMachineEmpty()
	}//End of class DrinkPurchaseListener()
	
	//Helper method for displayPanel
	private void buildDisplayPanel()
	{
		//Create panel
		displayPanel = new JPanel();
		displayPanel.setLayout(new FlowLayout());
		
		//Create GUI components
		lblPayment = new JLabel("Enter Payment Amount:");
		lblChange = new JLabel("Change Due:");
		txtPayment = new JTextField(20);
		txtChange = new JTextField(20);
		txtMessage = new JTextField(33);
		
		//Set second and third text field not editable
		txtChange.setEditable(false);
		txtMessage.setEditable(false);
		
		//Add ActionListener
		txtPayment.addActionListener(new PaymentListener());
		
		//Add components to displayPanel
		displayPanel.add(lblPayment);
		displayPanel.add(txtPayment);
		displayPanel.add(lblChange);
		displayPanel.add(txtChange);
		displayPanel.add(txtMessage);
	}//End of buildDisplayPanel()
	
	//Private inner class for txtPayment
	private class PaymentListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			//Reset change
			paymentChange = 0.0;
			
			//Get user input(coins)
			userPayment = Double.parseDouble(txtPayment.getText());
			
			//Check if valid payment
			if(userPayment - Math.round(userPayment) != 0)
			{
				txtPayment.setText("");
				txtChange.setText("");
				group.clearSelection();
				txtMessage.setText("Enter your coin payment in $1 or $2 coins.");
			}
			else
			{
				//Check if payment is enough
				if(array[index].getPrice() > userPayment)
				{
					group.clearSelection();
					txtPayment.setText("");
					txtChange.setText("");
					txtMessage.setText("Enter enough coin payment.");
				}
				else
				{
					//Calculate change
					paymentChange = userPayment - array[index].getPrice();
					array[index].setQuantity(array[index].getQuantity() - 1);
					
					group.clearSelection();
					txtChange.setText(String.format("$%.2f", paymentChange));
					txtMessage.setText("Thank you for your soft drink purchase.");
				}
			}
		}
	}
	
	//For Nimbus look and feel
	private static void setLookAndFeel()
	{
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		}	
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}//End of setLookAndFeel()
	
	public static void main(String[] args) 
	{
		//Create soft drink array
		SoftDrink []  array = new SoftDrink[5];
		array[0] = new SoftDrink("Cock", 1.25, 5);
		array[1] = new SoftDrink("Sprite", 2.2, 5);
		array[2] = new SoftDrink("Fanta Orange", 1.2, 5);
		array[3] = new SoftDrink("Mountain Dew", 2.35, 5);
		array[4] = new SoftDrink("Root Beer", 1.35, 5);
		
		//Create an instance of the frame
		setLookAndFeel();
		
		DrinkMachine frame = new DrinkMachine(array);
	}//End of main method
}//End of class