/**
 * Program Name:	Automobile.java
 * Purpose:		
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 19, 2021
 */

public class Automobile extends Transport
{
	//Declare instance fields
	private String maker;
	private String model;
	private int initialSpeed;
	private int maxSafeSpeed;
	
	/**
	 * Constructs a new Automobile object
	 * @param maker - initializes maker
	 * @param model - initializes model
	 * @param color - initializes color
	 * @param initialSpeed - initializes initialSpeed
	 * @param maxSafeSpeed - initializes maxSafeSpeed
	 */
	public Automobile(String maker, String model, String color, int initialSpeed, int maxSafeSpeed)
	{
		super("Automobile", color, initialSpeed);
		this.maker = maker;
		this.model = model;
		maxSafeSpeed = 0;
	}

	/**
	 * Gets the maker of this object  
	 * @return the maker
	 */
	public String getMaker()
	{
		return maker;
	}//End of getMaker()

	/**
	 * Gets the model of this object  
	 * @return the model
	 */
	public String getModel()
	{
		return model;
	}//End of getModel()

	/**
	 * Gets the maxSafeSpeed of this object  
	 * @return the maxSafeSpeed
	 */
	public int getMaxSafeSpeed()
	{
		return maxSafeSpeed;
	}//End of maxSafeSpeed()
	
	/**
	 * Prints information about current speed
	 * @see Transport#checkSpeed()
	 */
	public String checkSpeed()
	{		
		if((double)super.getForwardSpeed() / maxSafeSpeed > 0.95)
			return "Warning: vehicle speed is at safety limits! SLOW DOWN!";
		else
			return "Current car speed is within safe limits";
	}//End of checkSpeed()
	
	/**
	 * Displays an automobile's information
	 * @see Transport#toString()
	 */
	public String toString()
	{
		return super.toString()
				+ String.format(" This car  is a %s that is made by %s.\n", model, maker);
	}//End of toString()
}//End of class