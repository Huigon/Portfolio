/**
 * Program Name:	VehicleTester.java
 * Purpose:			To test Transport class and its subclasses
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 19, 2021
 */

public class VehicleTester 
{
	public static void main(String[] args)
	{
		//1. Create two objects
		Transport plane1 = new Aeroplane("Boeing", "787 Dreamliner", "Blue", 125);
		Transport car1 = new Automobile("Toyota", "Corolla", "Red", 65, 130);
		
		//2. Print objects' information
		System.out.print("Plane1 object: ");
		System.out.print(plane1.toString());
		System.out.print("Car1 object: ");
		System.out.println(car1.toString());
		
		//3. Print objects' checkSpeed()
		System.out.print("Plane1 object: ");
		System.out.println(plane1.checkSpeed());
		System.out.print("Car1 object: ");
		System.out.println(car1.checkSpeed());
		System.out.println();
		
		//4. Create an Aeroplane object
		Aeroplane plane2 = new Aeroplane("Diamond", "Katana", "white", 50);
		
		//5. Print information
		System.out.print("plane2 object: ");
		System.out.print(plane2.toString());
		
		//6. Change data and print information
		plane2.setAirborne(true);
		plane2.setForwardSpeed(65);
		
		System.out.println("Plane2 forward speed is: " + plane2.getForwardSpeed());
		System.out.print("Plane2 speed check: ");
		System.out.println(plane2.checkSpeed());
		
		//7. Change other data and print information
		plane2.setForwardSpeed(40);
		
		System.out.println("Plane2 forward speed is now " + plane2.getForwardSpeed());
		System.out.print("Plane2 speed check: ");
		System.out.println(plane2.checkSpeed());
	}//End of main method
}//End of class