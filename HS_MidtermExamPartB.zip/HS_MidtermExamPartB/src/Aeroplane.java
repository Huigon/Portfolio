/**
 * Program Name:	Aeroplane.java
 * Purpose:		
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 19, 2021
 */

public class Aeroplane extends Transport
{
	//Declare instance fields
	private String maker;
	private String model;
	private boolean isAirborne;
	private int stallSpeed;
	
	/**
	 * Constructs a new Aeroplane object
	 * @param maker - initializes maker
	 * @param model - initializes maker
	 * @param color - initializes color
	 * @param stallSpeed - initializes stallSpeed
	 */
	public Aeroplane(String maker, String model, String color, int stallSpeed)
	{
		super("Aeroplane", color, 0);
		setAirborne(false);
		this.maker = maker;
		this.model = model;
		this.stallSpeed = stallSpeed;
	}

	/**
	 * Gets the maker of this object  
	 * @return the maker
	 */
	public String getMaker()
	{
		return maker;
	}//End of getMaker()

	/**
	 * Gets the model of this object  
	 * @return the model
	 */
	public String getModel()
	{
		return model;
	}//End of getModel()

	/**
	 * Gets the isAirnorne of this object  
	 * @return the isAirborne
	 */
	public boolean isAirborne()
	{
		return isAirborne;
	}//End of isAirborne()

	/**
	 * Gets the stallSpeed of this object  
	 * @return the stallSpeed
	 */
	public int getStallSpeed()
	{
		return stallSpeed;
	}//End of getStallSpeed()

	/**
	 * Sets the isAirnorne of this object
	 * @param isAirnorne - the value to set
	 */
	public void setAirborne(boolean isAirborne)
	{
		this.isAirborne = isAirborne;
	}//End of setAirnorne()
	
	/**
	 * Prints information about current speed
	 * @see Transport#checkSpeed()
	 */
	public String checkSpeed()
	{		
		if(isAirborne && super.getForwardSpeed() <= stallSpeed)
			return "Warning: airspeed is at or below stall speed! Increase speed NOW!";
		else if(isAirborne && super.getForwardSpeed() > stallSpeed)
			return "Current airspeed is within safe limits.";
		else
			return "Aeroplane is not airborne at this time";
	}//End of checkSpeed()
	
	/**
	 * Displays an aeroplane's information
	 * @see Transport#toString()
	 */
	public String toString()
	{
		return super.toString()
				+ String.format(" This aeroplane is a %s that is made by %s.\n", model, maker);
	}//End of toString()
}//End of class