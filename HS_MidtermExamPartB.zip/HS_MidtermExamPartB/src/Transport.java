/**
 * Program Name:	Transport.java
 * Purpose:			An abstract for a Transport hierarchy, holds common attributes and abstract methods to be implemented in subclasses
 * @author			Huigon Shin, 1030403
 * @version			1.0
 * @since   		Feb 19, 2021
 */

public abstract class Transport 
{
	//Declare instance fields
	private String vehicleType;
	private String color;
	private boolean isMoving;
	private int forwardSpeed;
	
	/**
	 * Constructs a new Transport object
	 * @param vehicleType - initializes vehicleType
	 * @param color - initializes color
	 * @param forwardSpeed - initializes forwardSpeed
	 */
	public Transport(String vehicleType, String color, int forwardSpeed)
	{
		this.vehicleType = vehicleType;
		this.color = color;
		this.forwardSpeed = forwardSpeed;
		
		if(forwardSpeed > 0)
			isMoving = true;
		else if(forwardSpeed == 0)
			isMoving = false;
	}

	/**
	 * Gets the vehicleType of this object  
	 * @return the vehicleType
	 */
	public String getVehicleType()
	{
		return vehicleType;
	}//End of getVehicleType()

	/**
	 * Gets the color of this object  
	 * @return the color
	 */
	public String getColor()
	{
		return color;
	}//End of getColor()

	/**
	 * Gets the isMoving of this object  
	 * @return the isMoving
	 */
	public boolean getIsMoving()
	{
		return isMoving;
	}//End of getIsMoving()

	/**
	 * Gets the forwardSpeed of this object  
	 * @return the forwardSpeed
	 */
	public int getForwardSpeed()
	{
		return forwardSpeed;
	}//End of getForwardSpeed()

	/**
	 * Sets the forwardSpeed of this object
	 * @param newSpeed - the value to set
	 */
	public void setForwardSpeed(int newSpeed)
	{
		forwardSpeed = newSpeed;
		
		if(newSpeed > 0)
			isMoving = true;		
	}//End of setForwardSpeed()

	public abstract String checkSpeed();
	
	/**
	 * Displays a vehicle's information
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		return String.format("This vehicle is a(n) %s, its color is %s.\nCurrent speed is %d, so the in-motion sate is %b.", vehicleType, color, forwardSpeed, isMoving);
	}//End of toString()
}//End of class